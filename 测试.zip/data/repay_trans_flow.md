

table name:repay_trans_flow

|字段|类型|非空|索引|主键|默认值|说明|
|----|----|----|----|----|----|----|
|id|bigint| | | | | |
|project_no|string| | | | |项目编号|
|product_no|string| | | | |产品编号|
|flow_sn|string| | | | |流水号|
|due_bill_no|string| | | | |借据单号|
|trans_flow_type|string| | | | |交易类型 TransFlowTypeEnum|
|bank_trans_no|string| | | | |银行方交易流水号|
|trans_amount|decimal(12,2)| | | | |金额|
|currency|string| | | | |币种|
|bank_account_name|string| | | | |银行账户名称|
|bank_account_no|string| | | | |银行卡号|
|trans_time|bigint| | | | |交易时间|
|trans_status|string| | | | |交易状态|
|remark|string| | | | |交易备注|
|batch_date|string| | | | |批量时间|
|created_date|bigint| | | | | |
|last_modified_date|bigint| | | | | |
|flow_owner|string| | | | |流水的归属|
|trans_gateway|string| | | | |还款方式|
|is_confirmed|int| | | | |确认标识|
|online_flag|string| | | | |线上线下 ONLINE/OFFLINE|
|d_date|string| | | | | |
|p_type|string| | | | | |
