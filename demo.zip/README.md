# 工程简介

[蓝本](https://blog.csdn.net/weixin_44088274/article/details/106970073)
> 1.跑起来
> 2.实体类、Mapper、Controller
> 

注：  
1. 名称(列名+实体类属性名)   类型(主要是日期)
2. 拼接
3. url(指定url、定时or状态变化)

https://blog.csdn.net/dongtedu/article/details/104430531

https://blog.csdn.net/zbw18297786698/article/details/53913088

# 延伸阅读

