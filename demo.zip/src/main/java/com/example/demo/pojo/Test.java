package com.example.demo.pojo;

import lombok.Data;

import java.sql.Timestamp;

@Data
public class Test {
    private Long id;
    private String name;
    private Timestamp batchtime;
}
