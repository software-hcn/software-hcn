package com.example.demo.controller;

import com.example.demo.Mapper.TestMapper;
import com.example.demo.pojo.ResultVO;
import com.example.demo.pojo.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
public class TestController {
    @Autowired
    TestMapper testMapper;

    @RequestMapping("/getall")
    public ResultVO getAll(){
        //1.查询
       List<Test> tests = testMapper.findAll();
       //2.拼接


        //3.发送
       ResultVO resultVO = new ResultVO();
       resultVO.setCode(0);
       resultVO.setMsg("发送成功");
       resultVO.setData(tests);
       return  resultVO;
    }

}
