package com.example.demo.Mapper;

import com.example.demo.pojo.Test;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;

import java.util.List;

@Mapper
public interface TestMapper {

    @Select("select * from t_testtable")
    List<Test> findAll();
}
