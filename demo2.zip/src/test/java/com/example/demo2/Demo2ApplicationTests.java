package com.example.demo2;

import com.example.demo2.pojo.ResultVO;
import com.example.demo2.service.UserService;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Demo2ApplicationTests {
    @Autowired
    UserService userService;
    @Test
    void contextLoads() {
        ResultVO resultVO = userService.getAllUser();
        System.out.println(resultVO.getData());
    }

}
