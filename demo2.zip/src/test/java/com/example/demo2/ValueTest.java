package com.example.demo2;


import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.core.env.AbstractEnvironment;
import org.springframework.core.env.Environment;

@SpringBootTest
public class ValueTest {
    @Value("${test.url}")
  private String jdbc_url;
    @Autowired
    private Environment env;

    @Test
  public  void  Test(){
        System.out.println(jdbc_url);

        System.out.println(env.getProperty("test.url"));

    }
}
