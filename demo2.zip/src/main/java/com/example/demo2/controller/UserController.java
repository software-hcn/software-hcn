package com.example.demo2.controller;

import com.example.demo2.Mapper.UserMapper;
import com.example.demo2.pojo.BatchStatistic;
import com.example.demo2.pojo.ResultVO;
import com.example.demo2.pojo.User;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@Slf4j
public class UserController {

    @Autowired
    private UserMapper userMapper;
    @RequestMapping("/hello")
    public ResultVO Hello(){
        List<User> users = userMapper.findAllUser();
        System.out.println(users.get(0).getName());
        Gson gson = new GsonBuilder().serializeNulls().create();
        ResultVO resultVO = new ResultVO();
        resultVO.setCode("1");
        resultVO.setMsg("发送成功");
        resultVO.setData(gson.toJson(users));
        return resultVO;
    }

    @RequestMapping("/getalluserbytwotable")
    public ResultVO GetAllUser(){
        List<User> users = userMapper.findAllUserByTwoTable();
        System.out.println(users.get(0).getName());
        Gson gson = new GsonBuilder().serializeNulls().create();
        ResultVO resultVO = new ResultVO();
        resultVO.setCode("1");
        resultVO.setMsg("发送成功");
        resultVO.setData(gson.toJson(users));
        return resultVO;
    }



    @RequestMapping("/getallbatch")
    public ResultVO getBatchStatistic(){
        List<BatchStatistic> batchs = userMapper.findAllBatch();
        System.out.println(batchs);
        Gson gson = new Gson();
        ResultVO resultVO = new ResultVO();
        resultVO.setCode("1");
        resultVO.setMsg("Send Successful");
        resultVO.setData(gson.toJson(batchs));
        return resultVO;
    }

}
