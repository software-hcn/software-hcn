package com.example.demo2.utils;

import com.example.demo2.pojo.BatchStatistic;
import org.springframework.beans.factory.annotation.Value;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class DBUtils {
    @Value("${spring.datasource.url}")
    private  String jdbc_url ;
    public DBUtils(){
        System.out.println(this.jdbc_url);
    }


    public static List<BatchStatistic>  getBatchs() throws SQLException {
       // System.out.println(jdbc_url);
        String JDBC_DRIVER = "";
        String JDBC_URL = "jdbc:mysql://10.83.1.164/configuration?useUnicode=true&characterEncoding=utf-8&useSSL=false";
        String JDC_USER = "root";
        String JDBC_PWD= "Ws@Test!@E1#";
        //String sql  ="select * from test";
        String sql = "select b.project_id, b.project_name,\n" +
                "       b.batch_date, if(pc.status = 1,'自动跑批','手动跑批') as batch_type, concat_ws('\\\\',rbmc.content) as batch_module,\n" +
                "       case a.execute_status\n" +
                "           when '0' then '未执行'\n" +
                "           when  '1' then '正在执行'\n" +
                "           when  '2' then '执行成功'\n" +
                "           when '3' then '执行失败' end as execute_result,  if(a.check_data_status = 2,'校验失败','校验成功') as data_check,\n" +
                "       b.execute_start_time,b.execute_end_time,minute(b.average_timeIn_millis) as average_timeIn_millis\n" +
                "from test_a_copy a\n" +
                "         inner join test_a_ex_copy b on a.project_id = b.project_id\n" +
                "         inner join (select * from test_project_config_copy where status in (0, 1)) pc on a.project_id = pc.project_id\n" +
                "         inner join run_batch_monitor_check rbmc on a.project_id = rbmc.project_id limit 10";

        List<BatchStatistic> batchs = new ArrayList<>();

        try(Connection conn = DriverManager.getConnection(JDBC_URL, JDC_USER, JDBC_PWD)){
            try(PreparedStatement ps = conn.prepareStatement(sql)){
                //can set param
                try(ResultSet rs= ps.executeQuery()){
                    while(rs.next()){
                        BatchStatistic bs = new BatchStatistic();
                        bs.setProjectId(rs.getString("project_id"));
                        bs.setProjectName(rs.getString("project_name"));
                        bs.setBatchDate(rs.getString("batch_date"));
                        bs.setBatchType(rs.getString("batch_type"));
                        bs.setBatchModule(rs.getString("batch_module"));
                        bs.setExecuteResult(rs.getString("execute_result"));
                        bs.setDataCheck(rs.getString("data_check"));
                        bs.setExecuteStartTime(rs.getString("execute_start_time"));
                        bs.setExecuteEndTime(rs.getString("execute_end_time"));
                        bs.setAvgExecuteTime(rs.getString("average_timeIn_millis"));
                        batchs.add(bs);
                    }
                }
            }
        }




        return batchs;
    }

}
