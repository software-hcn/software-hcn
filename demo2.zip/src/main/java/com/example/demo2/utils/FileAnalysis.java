package com.example.demo2.utils;

import com.alibaba.excel.EasyExcel;
import com.example.demo2.pojo.FileAnalysis_InfoBean;
import com.example.demo2.pojo.FileAnalysis_MapBean;
import com.example.demo2.pojo.FileAnalysis_ResultBean;
import jxl.Sheet;
import jxl.Workbook;
import jxl.read.biff.BiffException;

import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import java.io.*;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class FileAnalysis {
    public static void main(String[] args) {
        /*
        * 1.读取stage信息(表格 or excel)
        * 2.读取ods信息
        * 3.映射关系 表名+字段
        * 4.输出为excel
        * 4.补充  映射关系：null、case——when,聚合
        *
        *
        * */
        //FileAnalysis_ReadFile_Test();
        //writeExcel();
       // readTable();
       // RegexTest();
        //RegexTest1();
       // List<FileAnalysis_MapBean> mapBeans = readMap();
        String wrtieFilePath ="D:\\Users\\caineng.huang\\Desktop\\resource\\document\\stage_ods\\映射.xlsx";

        writeExcel(wrtieFilePath);

    }


    public static List<FileAnalysis_MapBean> getMappingRealtoin(){

        List<FileAnalysis_MapBean> mapBeans = new ArrayList<>();
        //读取 赋值
        return mapBeans;
    }

    public static List<FileAnalysis_InfoBean> getInfoBean(String filePath){
        ArrayList<FileAnalysis_InfoBean> infoBeans = new ArrayList<>();
        //读取 赋值
        return infoBeans;
    }


    //读excel
    public static void  FileAnalysis_ReadFile_Test() {
        //excel  文本
        File file = new File("D:\\Users\\caineng.huang\\Desktop\\resource\\document\\stage_ods\\测试.xls");
        List excelList = readExcel(file);
        ArrayList<FileAnalysis_InfoBean> infoBeans = new ArrayList<>();
        System.out.println("list中的数据打印出来");
        int size = excelList.size();
        for (int i = 0; i < 2 ; i++) {   //行
            FileAnalysis_InfoBean bean = new FileAnalysis_InfoBean();
            List list = (List) excelList.get(i);
            if(list.size() == 3)
            {
                bean.setTableName("ods");
                bean.setFieldsName(list.get(0).toString());
                bean.setFieldsType(list.get(1).toString());
                bean.setFieldsComment(list.get(2).toString());
                bean.setFieldsExplain("说明");
                System.out.print(bean.toString());
            }

            System.out.println();
        }
    }

    public static List readExcel(File file) {
        try {
            // 创建输入流，读取Excel
            InputStream is = new FileInputStream(file.getAbsolutePath());
            // jxl提供的Workbook类
            Workbook wb = Workbook.getWorkbook(is);
            // Excel的页签数量
            int sheet_size = wb.getNumberOfSheets();
            for (int index = 0; index < sheet_size; index++) {
                List<List> outerList=new ArrayList<List>();
                // 每个页签创建一个Sheet对象
                Sheet sheet = wb.getSheet(index);
                // sheet.getRows()返回该页的总行数
                for (int i = 0; i < sheet.getRows(); i++) {
                    List innerList=new ArrayList();
                    // sheet.getColumns()返回该页的总列数
                    for (int j = 0; j < sheet.getColumns(); j++) {
                        String cellinfo = sheet.getCell(j, i).getContents();
                        if(cellinfo.isEmpty()){
                            continue;
                        }
                        innerList.add(cellinfo);
                        System.out.print(cellinfo);
                    }
                    outerList.add(i, innerList);
                    System.out.println();
                }
                return outerList;
            }
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (BiffException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }


    //写入excel
    public  static  void writeExcel(String fileName){
       // String fileName = "D:\\Users\\caineng.huang\\Desktop\\resource\\document\\stage_ods\\测试.xls";
        EasyExcel.write(fileName, FileAnalysis_MapBean.class).sheet("模板").doWrite(readMap());
    }
    private static List<List<Object>> dataList() {
        List<List<Object>> list = new ArrayList<>();
        for (int i = 0; i < 10; i++) {
            List<Object> data = new ArrayList<>();
            data.add("张三");
            data.add(25);
            data.add(new Date());
            list.add(data);
        }
        return list;
    }

    //读取所有需要操作的表格信息
    public static List<String> readTable(){
        List<String> tables = new ArrayList<>();
        String pathname = "D:\\Users\\caineng.huang\\Desktop\\resource\\document\\stage_ods\\过滤表.txt";
        String tabelRex1 = "CREATE.+`.*`";
        Pattern p1 = Pattern.compile(tabelRex1);
        String tabelRex2="`.*`";
        Pattern p2 = Pattern.compile(tabelRex2);
        try{
            /* 读入TXT文件 */

            File filename = new File(pathname);
            InputStreamReader reader = new InputStreamReader(
                    new FileInputStream(filename));
            BufferedReader br = new BufferedReader(reader);
            String line = "";
            line = br.readLine();
            while (line != null) {
                Matcher m1 = p1.matcher(line);
                if(m1.find()){    //提取表名
                    Matcher m2 = p2.matcher(line);
                    if(m2.find()){
                        String table =  m2.group();
                        tables.add(table.substring(1,table.length()-2));
                    }
                }
                line = br.readLine(); // 一次读入一行数据
            }

        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        if(tables.size() >0)
         System.out.println(tables.get(0));
        return tables;

    }

    //读取“映射” 生成 excel
    public static List<FileAnalysis_MapBean> readMap(){
        List<FileAnalysis_MapBean> mapBeans = new ArrayList<>();
        String pathname = "D:\\Users\\caineng.huang\\Desktop\\resource\\document\\stage_ods\\映射.txt";
        String splitRex = "as";
        Pattern p1 = Pattern.compile(splitRex);
        String odsTN = "ods";

        try{
            /* 读入TXT文件 */

            File filename = new File(pathname);
            InputStreamReader reader = new InputStreamReader(
                    new FileInputStream(filename));
            BufferedReader br = new BufferedReader(reader);
            String line = "";
            line = br.readLine();
            while (line != null) {
                if(!line.isEmpty()){
                    FileAnalysis_MapBean mapBean = new FileAnalysis_MapBean();
                    String[] splits = p1.split(line);
                    if(splits.length == 2){
                        mapBean.setOdsTN(odsTN);
                        mapBean.setOdsFN(splits[1].trim());

                        String stage = splits[0].trim();
                        if(stage.length() > 1 && stage.charAt(1) == '.'){
                            mapBean.setStageTN(stage.substring(0,1));
                            mapBean.setStageFN(stage.substring(2));
                        }else
                        {
                            mapBean.setStageFN(stage);
                        }
                    }
                    mapBeans.add(mapBean);
                }
                line = br.readLine(); // 一次读入一行数据
            }

        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        if(mapBeans.size() >0)
            System.out.println(mapBeans.get(0));
        return mapBeans;
    }






    
    
    



    //正则测试
  private static void RegexTest(){
      String content = "CREATE TABLE IF NOT EXISTS `ods.linkman_info`(";
      String tableRex = "CREATE.+`.*`";
      String tableRex1 = "`.*`";
      Pattern p = Pattern.compile(tableRex);
      Matcher m = p.matcher(content);

      Pattern p1 = Pattern.compile(tableRex1);
      Matcher m1 = p1.matcher(content);
        try{
            if(m1.find()){
                String table = m1.group();
                System.out.println(table);
            }

        }catch (Exception ex){

        }
      boolean isMatch =  m.find();
  }
    //正则测试1
  private static void RegexTest1(){
      Pattern p1 = Pattern.compile(".");
      String content1 = "a.flow_sn";
      if(content1.charAt(1) == '.'){
          System.out.println(content1.substring(2));
      }
      String[] split1 = p1.split(content1);
      String[] split2 = content1.split(".");
      for (String s :
              split1) {
          System.out.println(s);
      }


      String content = "b.product_no              as product_id";
        String splitRex = "as";
      Pattern p = Pattern.compile(splitRex);
     // Matcher m = p.matcher(content);
      String[] split = p.split(content);
      for (String s : split) {
          System.out.println(s);
      }
  }

}
