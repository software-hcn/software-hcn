package com.example.demo2;

import com.example.demo2.pojo.ResultVO;
import com.example.demo2.pojo.User;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import lombok.val;

import java.sql.Date;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

public class TestGson {
    public static void main(String[] args) {
        testListJson();
    }

    public static void  testObejct(){
        Gson gson = new Gson();
        User user = new User();
        user.setId(1);
        user.setName("留得瓦");
       // user.setTime(null);
        val jsonString =  gson.toJson(user);
        System.out.println(jsonString);
    }

    public  static  void testListJson(){
        //Gson gson = new Gson();
        Gson gson = new GsonBuilder().serializeNulls().create();
        List<User> users = new ArrayList<>();
        users.add(new User(1,"留得瓦"));
        users.add(new User(2,"章雪友"));
        users.add(new User(3,"梨鸣"));
        users.add(new User(4,"锅副成"));
        ResultVO resultVO = new ResultVO();
        resultVO.setCode("1");
        resultVO.setMsg("发送成功");
        resultVO.setData(users);
        String jsonString = gson.toJson(resultVO);
        System.out.println(jsonString);

    }








}
