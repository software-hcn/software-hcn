package com.example.demo2;

import com.example.demo2.pojo.User;
import com.example.demo2.utils.HTTPUtils;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

import java.util.HashMap;
import java.util.Map;

public class TestHttp {
    public static void main(String[] args) throws Exception {
       /* String url = "https://api.tapd.cn/board_cards";
        Map<String,String> params = new HashMap<String,String>();
        params.put("workspace_id","20355782");
        params.put("id","1020355782500624255");*/

        String url = "http://www.baidu.com/s?wd=java";

        getBatchData(url,null,null);
    }

    public static void getBatchData(String url ,Map<String,String> params,String cookie) throws Exception{
        //1.查询

        //2.拼接
        User data = new User();
        data.setId(1);
        data.setName("跑批统计");
        //3.发送
       // params.put("description",data.toString());
        String result =  HTTPUtils.getReqAndGetRespEntity(url,params,cookie);
        if(result != null) {
            System.out.println("返回结果=================>"+result);
            ObjectMapper objectMapper = new ObjectMapper();
            JsonNode respData = objectMapper.readTree(result).get("data");
            System.out.println("返回结果=================>"+respData);
        }
    }
}
