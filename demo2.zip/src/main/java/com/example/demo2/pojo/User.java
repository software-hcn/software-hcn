package com.example.demo2.pojo;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.sql.Timestamp;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class User {
    private  Integer id;
    private String name;
   // private Integer id_2;
  //  private String name_2;
   // private Timestamp time;
}
