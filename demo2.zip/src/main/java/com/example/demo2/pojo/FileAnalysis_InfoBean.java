package com.example.demo2.pojo;

import lombok.Data;

@Data
public class FileAnalysis_InfoBean {
    private String tableName;
    private String fieldsName;
    private String fieldsType;
    private String fieldsComment;
    private String fieldsExplain;
}
