package com.example.demo2.pojo;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class BatchStatistic {
    private String projectId;
    private String projectName;
    private String batchDate;
    private String batchType;
    private String batchModule;
    private String executeResult;
    private String dataCheck;
    private String executeStartTime;
    private String executeEndTime;
    private String avgExecuteTime;
}
