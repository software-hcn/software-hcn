package com.example.demo2.pojo;

import com.alibaba.excel.annotation.ExcelProperty;

public class FileAnalysis_ResultBean {
    @ExcelProperty(value = "数据库名")
    private String dbName ;
    @ExcelProperty(value = "数据库名注释")
    private String dbNameComment ;



    @ExcelProperty(value = "表名")
    private String tableName ;
    @ExcelProperty(value = "表类型")
    private String tableType ;
    @ExcelProperty(value = "表名注释")
    private String tableNameComment ;
    @ExcelProperty(value = "字段名")
    private String fieldsName ;
    @ExcelProperty(value = "字段注释")
    private String fieldsNameComment ;
    @ExcelProperty(value = "字段类型")
    private String fieldsType ;
    @ExcelProperty(value = "字段说明")
    private String fieldsExplain ;

    @ExcelProperty(value = "Stage_表")
    private String stage_tableName ;
    @ExcelProperty(value = "Stage_字段名")
    private String stage_fieldsName ;
    @ExcelProperty(value = "Stage_字段注释")
    private String stage_fieldsNameComment ;
    @ExcelProperty(value = "Stage_字段类型")
    private String stage_fieldsType ;
    @ExcelProperty(value = "Stage_字段说明")
    private String stage_fieldsExplain ;


}
