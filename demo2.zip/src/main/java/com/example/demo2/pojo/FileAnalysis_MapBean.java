package com.example.demo2.pojo;


import lombok.Data;

@Data
public class FileAnalysis_MapBean {
    //ods表名
    private String odsTN;
    //ods字段名
    private String odsFN;

    //stage表名
    private String stageTN;
    //stage字段名
    private String stageFN;
    //stage字段类型
    private String stageFType;
    //stage字段注释
    private String stageFComment;
    //stage字段说明
    private String stageFExplain;

}
