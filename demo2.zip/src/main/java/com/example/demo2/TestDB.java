package com.example.demo2;

import com.example.demo2.Mapper.UserMapper;
import com.example.demo2.pojo.BatchStatistic;
import com.example.demo2.pojo.User;
import com.example.demo2.service.impl.UserServiceImpl;
import com.example.demo2.utils.DBUtils;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import org.springframework.beans.factory.annotation.Autowired;

import java.sql.SQLException;
import java.util.List;

public class TestDB {

    public static void main(String[] args) {
      //  testByMybatis();
      //  testByDBUtils();
        DBUtils dbutils = new DBUtils();
    }

    public static void testByDBUtils(){
        try {
            List<BatchStatistic> batchs = DBUtils.getBatchs();
            Gson gson = new GsonBuilder().serializeNulls().create();
            System.out.println(gson.toJson(batchs));

        } catch (SQLException throwables) {
            System.out.println("异常");
        }
    }

    public static void testByMybatis(){
        UserServiceImpl userService = new UserServiceImpl();
        System.out.println(userService.getAllUser().getData());
    }
}
