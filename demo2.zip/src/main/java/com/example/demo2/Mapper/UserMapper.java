package com.example.demo2.Mapper;

import com.example.demo2.pojo.BatchStatistic;
import com.example.demo2.pojo.User;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Result;
import org.apache.ibatis.annotations.Results;
import org.apache.ibatis.annotations.Select;

import java.util.List;

@Mapper
public interface UserMapper {
    @Select("select * from test")
   List<User> findAllUser();

    @Select("select t1.id,t2.name" +
            "from test t1 left join test2 t2 on t1.id = t2.id")
    List<User> findAllUserByTwoTable();

    @Select("select b.project_id,\n" +
            "       b.project_name,\n" +
            "       b.batch_date,\n" +
            "       if(pc.status = 1, '自动跑批', '手动跑批')           as batch_type,\n" +
            "       concat_ws('\\\\', rbmc.content)               as batch_module,\n" +
            "       case a.execute_status\n" +
            "           when '0' then '未执行'\n" +
            "           when '1' then '正在执行'\n" +
            "           when '2' then '执行成功'\n" +
            "           when '3' then '执行失败' end                as execute_result,\n" +
            "       if(a.check_data_status = 2, '校验失败', '校验成功') as data_check,\n" +
            "       b.execute_start_time,\n" +
            "       b.execute_end_time,\n" +
            "        round(b.average_timeIn_millis /(60*1000))                as average_timeIn_minutes\n" +
            "from test_a_copy a\n" +
            "         inner join test_a_ex_copy b on a.project_id = b.project_id\n" +
            "         inner join (select * from test_project_config_copy where status in (0, 1)) pc on a.project_id = pc.project_id\n" +
            "         inner join run_batch_monitor_check rbmc on a.project_id = rbmc.project_id limit 1")
    @Results(id = "batchMapper" ,value = {
            @Result(column = "project_id",property = "projectId"),
            @Result(column = "project_name",property = "projectName"),
            @Result(column = "batch_date",property = "batchDate"),
            @Result(column = "batch_type",property = "batchType"),
            @Result(column = "batch_module",property = "batchModule"),
            @Result(column = "execute_result",property = "executeResult"),
            @Result(column = "data_check",property = "dataCheck"),
            @Result(column = "execute_start_time",property = "executeStartTime"),
            @Result(column = "execute_end_time",property = "executeEndTime"),
            @Result(column = "average_timeIn_minutes",property = "avgExecuteTime"),
    })
    List<BatchStatistic> findAllBatch();
}
