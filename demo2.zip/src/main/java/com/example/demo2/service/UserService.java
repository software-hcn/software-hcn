package com.example.demo2.service;

import com.example.demo2.pojo.ResultVO;
import com.example.demo2.pojo.User;

import java.util.List;

public interface UserService {
        ResultVO getAllUser();
        ResultVO getAllUserByTwoTable();
}
