package com.example.demo2.service.impl;

import com.example.demo2.Mapper.UserMapper;
import com.example.demo2.pojo.ResultVO;
import com.example.demo2.pojo.User;
import com.example.demo2.service.UserService;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Slf4j
@Service
public class UserServiceImpl implements UserService {
    @Autowired
    UserMapper userMapper;

    @Override
    public ResultVO getAllUser() {
       List<User> users = userMapper.findAllUser();
       Gson gson = new GsonBuilder().serializeNulls().create();
       ResultVO resultVO = new ResultVO();
       resultVO.setCode("1");
       resultVO.setMsg("Send msg Successful");
       resultVO.setData(gson.toJson(users));
       return resultVO;
    }

    @Override
    public ResultVO getAllUserByTwoTable() {
        List<User> users = userMapper.findAllUserByTwoTable();
        Gson gson = new GsonBuilder().serializeNulls().create();
        ResultVO resultVO = new ResultVO();
        resultVO.setCode("1");
        resultVO.setMsg("Send msg Successful");
        resultVO.setData(gson.toJson(users));
        return resultVO;
    }

}
